from django.shortcuts import render,redirect
from .models import Plan
import datetime
import time
from datetime import timedelta
# Create your views here.
def home(request):
    plans=Plan.objects.order_by("deadline")
    """
    now=time.strftime("%Y-%m-%d",time.localtime(time.time()))
    d_days=[]
    for plan in plans:
        dl=plan.deadline
        now_list=now.split("-")
        dl_list=dl.split("-")
        result=["%d년 %d월 %d일"] %(dl_list[0]-now_list[0],dl_list[1]-now_list[1],dl_list[2]-now_list[2])
        d_days+=result
        deadline.split("-")[]
    """
    return render(request, 'home.html', {'plans':plans})

def detail(request, plan_pk):
    plan=Plan.objects.get(pk=plan_pk)
    return render(request, 'detail.html', {'plan':plan})

def create(request):
    if request.method=='POST':
        
        #현재시간을, 내가 원하는 문자열 형태로 구현 
        now=time.strftime("%Y-%m-%d",time.localtime(time.time()))
        #연산을 수행하기 위해 datetime 객체로 만듦.
        d_now=datetime.datetime.strptime(now, '%Y-%m-%d')
        #마감시간을 datetime 객체로 변환
        d_dl=datetime.datetime.strptime(request.POST["deadline"], '%Y-%m-%d')
        #datetime 객체끼리 뺌, timedelta객체 반환
        d_day_delta=d_dl - d_now
        #delta객체에서 '일'추출한 후 문자열로 바꿔서 전달하기
        d_day_result=str(d_day_delta.days)
        
        new_plan=Plan.objects.create(
            title=request.POST["title"],
            content=request.POST["content"],
            deadline=request.POST["deadline"],
            #모델의 d_day 어트리부트에 위에서 계산한 값 삽임
            d_day=d_day_result,
            )
        return redirect('detail', new_plan.pk)

    else:
        return render(request, "create.html")

def update(request, plan_pk):
    plan=Plan.objects.get(pk=plan_pk)
    if request.method=='POST':
        #내용 수정때도 동일하게 디데이를 다시 계산해주기
        now=time.strftime("%Y-%m-%d",time.localtime(time.time()))
        d_now=datetime.datetime.strptime(now, '%Y-%m-%d')
        d_dl=datetime.datetime.strptime(request.POST["deadline"], '%Y-%m-%d')
        d_day_delta=d_dl - d_now
        d_day_result=str(d_day_delta.days)

        Plan.objects.filter(pk=plan_pk).update(
            title=request.POST['title'],
            content=request.POST['content'],
            deadline=request.POST["deadline"],
            now=time.strftime("%Y-%m-%d",time.localtime(time.time())),
            d_day=d_day_result,           
            ) 
        return redirect('detail', plan_pk)
    
    else:
        return render(request, "update.html", {'plan':plan})

def delete(request, plan_pk):
    Plan.objects.get(pk=plan_pk).delete()
    return redirect('home')