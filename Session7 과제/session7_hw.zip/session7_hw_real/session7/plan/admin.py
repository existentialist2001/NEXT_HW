from django.contrib import admin
from .models import Plan
# Register your models here.
admin.site.register(Plan)
