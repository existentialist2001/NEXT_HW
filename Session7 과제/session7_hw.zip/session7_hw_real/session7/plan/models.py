from django.db import models

# Create your models here.

class Plan(models.Model):
    title=models.CharField(max_length=30)
    content=models.TextField()
    deadline=models.TextField(null = True)
    d_day=models.TextField(null = True)
    def __str__(self):
        return self.title